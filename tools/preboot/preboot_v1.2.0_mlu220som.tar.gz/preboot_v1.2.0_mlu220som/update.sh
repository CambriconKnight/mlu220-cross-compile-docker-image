#!/bin/bash
# -------------------------------------------------------------------------------
# Filename:     update.sh
# Revision:     1.0.0
# Date:         2021/06/09
# Description:  1.校驗MD5
#               2.升級當前目錄下preboot.bin到當前MLU220SOM。
#               3.查看preboot版本
# Example:      直接運行腳本: ./update.sh
# Depends:      preboot.bin
# Notes:
# -------------------------------------------------------------------------------
UPDATE_FILENAME="preboot.bin"
UPDATE_MD5SUM_TXT_NAME="md5sum.txt"

md5sum_file() {
    echo "[# MD5 $1: "
    result=$(md5sum -c ${UPDATE_MD5SUM_TXT_NAME} | grep $1)
    if [[ "$result" != "./$1: OK" ]]
    then
        echo "Damaged File(md5sum)!(${1})"
        exit -1
    fi
    echo "   OK"
}

update_file() {
    echo "[# Update $1: "
    mtd_debug erase /dev/mtd0 0x0 0x20000
    file_size=`wc ./${1} | awk '{printf "0x%x",$3}'`
    echo $file_size
    result=$(mtd_debug write /dev/mtd0 0x0 $file_size ./${1} | grep $1)
    flag_result=`echo $result|grep 'to address'|wc -l`
    if [[ "$flag_result" != "1" ]]
    then
        echo "Upgrade fail!(${1})"
        exit -1
    fi
    echo "   OK"
}
# 1.校驗需要升級文件的MD5值
md5sum_file $UPDATE_FILENAME

# 2.升級當前目錄下 preboot.bin 到當前MLU220SOM
update_file $UPDATE_FILENAME

# 3.查看preboot版本(升級後,需要斷電重新啓動操作系統,啓動後使用如下命令查看preboot版本.)
devmem 0x8000020008
