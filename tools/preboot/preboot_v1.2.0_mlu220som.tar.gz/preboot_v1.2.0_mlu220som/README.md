# 升级说明
此版本preboot V1.2.0可解决高温死机问题（优化了DDR的配置参数）
升级步骤：可以直接在MLU220SOM上的操作系统上进行如下升级操作：
## 校验md5sum
升级前先校验md5sum
```bach
[root@cambricon /cambricon/test/preboot/edge_v1.2.0]# ls
md5sum.txt   preboot.bin
[root@cambricon /cambricon/test/preboot/edge_v1.2.0]# md5sum -c md5sum.txt
./preboot.bin: OK
```
## 升级preboot
按照以下步驟升級或者直接執行update.sh腳本進行升級.
```bach
[root@cambricon /cambricon/test/preboot/edge_v1.2.0]# mtd_debug erase /dev/mtd0 0x0 0x20000
Erased 131072 bytes from address 0x00000000 in flash
[root@cambricon /cambricon/test/preboot/edge_v1.2.0]# file_size=`wc ./preboot.bin | awk '{printf "0x%x",$3}'`
[root@cambricon /cambricon/test/preboot/edge_v1.2.0]# echo $file_size
0x7fa8
[root@cambricon /cambricon/test/preboot/edge_v1.2.0]# mtd_debug write /dev/mtd0 0x0 $file_size ./preboot.bin
Copied 32680 bytes from ./preboot.bin to address 0x00000000 in flash
```
## 查看preboot版本
升級後,需要斷電重新啓動操作系統,啓動後使用如下命令查看preboot版本.
```bach
[root@cambricon ~]# devmem 0x8000020008
0x0000011E
```
注1：更好的办法是把v1.2.0的preboot.bin替换调原sdkv1.7.0的release/neuware/opensrc/resource/preboot_evb.bin，然后重新编译，输出的bsp包就包含preboot v1.2.0了
注2：预计（20210723）即将发布的1.7.602版本会默认包含了这个1.2.0版本preboot.